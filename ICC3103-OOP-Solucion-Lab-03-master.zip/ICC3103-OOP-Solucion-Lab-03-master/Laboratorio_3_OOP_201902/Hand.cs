﻿using Laboratorio_3_OOP_201902.Cards;
using System;
using System.Collections.Generic;
using System.Text;

namespace Laboratorio_3_OOP_201902
{
    public class Hand : Deck
    {

        public Hand()
        {
            
        }
       
    }
}
